#!/bin/sh -f
xv_path="/opt/Xilinx/Vivado/2015.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim bgt_test_behav -key {Behavioral:sim_1:Functional:bgt_test} -tclbatch bgt_test.tcl -view /home/s1645821/git/assessment2/Digital-Lab-4/Processor/wrapper_tb_func_impl.wcfg -log simulate.log
